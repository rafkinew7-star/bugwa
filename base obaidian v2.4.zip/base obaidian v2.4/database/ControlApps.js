module.exports = {
  tokens: "7812290821:AAFzF23bx9A1Wt1yJHy6tOIbe-f7RBMJ-ag", 
  owner: "7588105919", 
  port: "1202", // Ini Wajib Jangan Diubah
  ipvps: "206.189.144.114" // Jangan Diubah Nanti Eror!!
};